import os
import pandas as pd
import streamlit as st
import matplotlib.pyplot as plt

# Define data paths
data_dir = r"C:\Users\usen\Mini project 2\data\output_csv"  # Folder containing ticker-wise CSVs
sector_mapping_file = r"C:\Users\usen\Mini project 2\data\sector\cleaned_sector_mapping.csv"  # Sector mapping CSV

# Load sector mapping
sector_mapping = pd.read_csv(sector_mapping_file)

# Ensure required columns exist
if "Ticker" not in sector_mapping.columns or "sector" not in sector_mapping.columns:
    st.error("Sector mapping CSV must contain 'Ticker' and 'sector' columns!")
    st.stop()

# Initialize dataframe to store yearly returns
sector_returns = []

# Process each stock CSV file
for ticker in os.listdir(data_dir):
    ticker_folder = os.path.join(data_dir, ticker)
    csv_path = os.path.join(ticker_folder, f"{ticker}.csv")
    
    if os.path.isfile(csv_path):
        df = pd.read_csv(csv_path)

        # Ensure required columns exist
        if "date" not in df.columns or "close" not in df.columns:
            st.warning(f"Skipping {ticker}: Missing 'date' or 'close' column")
            continue
        
        # Convert date column to datetime format
        df["date"] = pd.to_datetime(df["date"])
        df["year"] = df["date"].dt.year
        
        # Calculate yearly return (percentage change)
        yearly_returns = df.groupby("year")["close"].pct_change().mean() * 100  # Convert to percentage
        
        # Get sector for the ticker
        sector_row = sector_mapping[sector_mapping["Ticker"] == ticker]
        if not sector_row.empty:
            sector = sector_row["sector"].values[0]
            sector_returns.append({"Sector": sector, "Yearly Return": yearly_returns.mean()})

# Convert to DataFrame
sector_df = pd.DataFrame(sector_returns)

# Aggregate average returns per sector
sector_avg_returns = sector_df.groupby("Sector")["Yearly Return"].mean().reset_index()

# Streamlit UI
st.title("📊 Sector-wise Performance Analysis")
st.write("This chart shows the **average yearly return** for each sector.")

# Plot bar chart
fig, ax = plt.subplots(figsize=(10, 5))
ax.bar(sector_avg_returns["Sector"], sector_avg_returns["Yearly Return"], color="skyblue")
ax.set_xlabel("Sector")
ax.set_ylabel("Average Yearly Return (%)")
ax.set_title("Sector-wise Stock Performance")
plt.xticks(rotation=45)
st.pyplot(fig)
